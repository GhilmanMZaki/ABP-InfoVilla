import 'dart:convert';

import 'package:infovillamobile/services/user_services.dart';
import '../global.dart';
import '../model/ApiResponse.dart';
import 'package:http/http.dart' as http;

import '../model/villaModel.dart';

// get all Villa
Future<ApiResponse> getVilla() async {
  ApiResponse apiResponse = ApiResponse();
  String token = await getToken();
  final response = await http.get(Uri.parse(villaURL), headers: {
    'Accept': 'application/json',
    'Authorization': 'Bearer $token'
  });

  switch (response.statusCode) {
    case 200:
      apiResponse.data = jsonDecode(response.body)['villa'];
      break;
    case 401:
      apiResponse.error = unauthorized;
      break;
    default:
      apiResponse.error = somethingWentWrong;
      break;
  }
  return apiResponse;
}
