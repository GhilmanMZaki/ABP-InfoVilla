class Review {
  int? id;
  int? user_id;
  int? villa_id;
  String? review;
  String? rating;
  Review({
    this.id,
    this.user_id,
    this.villa_id,
    this.review,
    this.rating,
  });

// map json to Review model

  factory Review.fromJson(Map<String, dynamic> json) {
    return Review(
      id: json['id'],
      user_id: json['user_id'],
      villa_id: json['villa_id'],
      review: json['review'],
      rating: json['rating'],
    );
  }
}
