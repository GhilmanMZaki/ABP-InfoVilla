import 'package:flutter/material.dart';
import 'package:infovillamobile/model/villaModel.dart';
import 'package:infovillamobile/screen/villa_card.dart';

import '../global.dart';
import '../model/ApiResponse.dart';
import '../services/user_services.dart';
import '../services/villa_services.dart';
import 'login.dart';

class Villa_Screen extends StatefulWidget {
  Villa_Screen({Key? key}) : super(key: key);

  @override
  State<Villa_Screen> createState() => _Villa_ScreenState();
}

class _Villa_ScreenState extends State<Villa_Screen> {
  List<dynamic> _villaList = [];
  int userId = 0;
  bool _loading = true;

  Future<void> retrieveVilla() async {
    userId = await getUserId();
    ApiResponse response = await getVilla();

    if (response.error == null) {
      setState(() {
        _villaList = response.data as List<dynamic>;
        _loading = _loading ? !_loading : _loading;
      });
    } else if (response.error == unauthorized) {
      logout().then((value) => {
            Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (context) => Login()),
                (route) => false)
          });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('${response.error}'),
      ));
    }
  }

  @override
  void initState() {
    retrieveVilla();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return _loading
        ? Center(child: CircularProgressIndicator())
        : RefreshIndicator(
            onRefresh: () {
              return retrieveVilla();
            },
            child: Container(
                child: ListView.builder(
                    itemCount: 2,
                    itemBuilder: (context, index) {
                      return Container(
                        margin: EdgeInsetsDirectional.fromSTEB(20, 0, 20, 40),
                        child: AspectRatio(
                          aspectRatio: 3 / 1,
                          child: Container(
                            color: Colors.red,
                            child: Row(
                              children: [
                                AspectRatio(
                                  aspectRatio: 1 / 1,
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(10),
                                    child: Image.network(
                                      'https://picsum.photos/250?image=9',
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                                SizedBox(width: 20),
                                AspectRatio(
                                  aspectRatio: 4 / 3,
                                  child: Column(
                                    children: [],
                                  ),
                                )
                              ],
                            ),
                          ),
                        ),
                      );
                    })),
          );
  }
}
