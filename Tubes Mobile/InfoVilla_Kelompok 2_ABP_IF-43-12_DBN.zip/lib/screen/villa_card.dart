import 'package:flutter/material.dart';
import 'package:infovillamobile/screen/villa_card.dart';

class villa_card extends StatefulWidget {
  villa_card({Key? key}) : super(key: key);

  @override
  State<villa_card> createState() => _villa_cardState();
}

class _villa_cardState extends State<villa_card> {
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsetsDirectional.fromSTEB(20, 0, 20, 40),
      child: AspectRatio(
        aspectRatio: 3 / 1,
        child: Container(
          color: Colors.red,
          child: Row(
            children: [
              AspectRatio(
                aspectRatio: 1 / 1,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: Image.network(
                    'https://picsum.photos/250?image=9',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              SizedBox(width: 20),
              AspectRatio(
                aspectRatio: 4 / 3,
                child: Column(
                  children: [],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
