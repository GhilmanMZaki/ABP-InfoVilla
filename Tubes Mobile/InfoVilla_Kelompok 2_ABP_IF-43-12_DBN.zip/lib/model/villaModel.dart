import 'reviewModel.dart';

class Villa {
  int? id;
  String? namaVilla;
  String? deskripsi;
  String? lokasi;
  String? harga;
  String? image;
  Review? review;
  double? rating;
  int? favoriteCount;
  int? reviewCount;
  bool? selfLiked;

  Villa({
    this.id,
    this.deskripsi,
    this.lokasi,
    this.harga,
    this.image,
    this.review,
    this.rating,
    this.favoriteCount,
    this.reviewCount,
    this.selfLiked,
  });

// map json to Villa model

  factory Villa.fromJson(Map<String, dynamic> json) {
    return Villa(
        id: json['id'],
        deskripsi: json['deskripsi'],
        lokasi: json['lokasi'],
        harga: json['harga'],
        image: json['image'],
        review: Review(
          id: json['id'],
          user_id: json['user_id'],
          villa_id: json['villa_id'],
          review: json['review'],
          rating: json['rating'],
        ),
        rating: json['rating'],
        favoriteCount: json['favorite_count'],
        reviewCount: json['review_count'],
        selfLiked: json['likes'].length > 0);
  }
}
